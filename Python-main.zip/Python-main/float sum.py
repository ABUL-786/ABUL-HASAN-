num1=input('enter first number:')
num2=input('enter second number:')

add=float(num1)+float(num2)
sub=float(num1)-float(num2)
multipl=float(num1)*float(num2)
division=float(num1)/float(num2)

print('The sum of \t {0}\n and \n {1}is{2} \n {0}and{1}is{3} \n {0}and{1}is{4} \n {0}and{1}is{5}  '.format(num1,num2,add,sub,multipl,division))

























