name = input("enter your name:")

print("hello," + name + "! welcom to python programing...")

age = input("enter your age:")

print("hello,"+name+"your age"+age)

cource = input("enter your cource:")

print("Welcome" + name + "your age"+age+ "your cource" + cource)

college = input("enter your college name:")

District = input("enter your District:")

print("Welcome:" + name + "\n your age:"+age+ "\n your cource:" + cource + "\n college:" + college + "\n your District:" +District)
