age=int(input("enter age:"))
if age>=18:
    print("your eligble for vote")
else:
    print("your not eligble to vote")

