for i in range(5):
    for j in range(5):
        print(f"({i},{j})", end=" ")
    print()
