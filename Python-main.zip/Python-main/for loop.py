num = int(input("Enter a number: "))
for i in range(1, 15):
    print(f"{i} / {num} = {num * i}")
