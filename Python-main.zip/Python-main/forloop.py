fruit=('apple','orenge','grapes')
for fruit in fruit:
    print(fruit)
